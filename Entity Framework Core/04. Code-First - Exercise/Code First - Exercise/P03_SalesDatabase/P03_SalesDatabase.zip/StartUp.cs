﻿namespace P03_SalesDatabase
{
    using System;

    public class StartUp
    {
        public static void Main()
        {
           
        }
    }
}
