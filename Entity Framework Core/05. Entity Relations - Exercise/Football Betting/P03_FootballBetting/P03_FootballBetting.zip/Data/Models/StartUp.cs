﻿namespace P03_FootballBetting
{
    using P03_FootballBetting.Data;
    using System;

    public class StartUp
    {
       public  static void Main()
        {
            var db = new FootballBettingContext();  
        }
    }
}
