﻿namespace CarDealer.DTO
{
    public class SupplierDTO
    {
        public string Name { get; set; }

        public bool isImporter { get; set; }
    }
}
