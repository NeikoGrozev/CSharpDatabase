﻿namespace CarDealer.DTO
{
    using System;

    public class CustomerDTO
    {
        public string Name { get; set; }

        public DateTime BirthDate { get; set; }

        public bool isYoungDriver { get; set; }
    }
}
